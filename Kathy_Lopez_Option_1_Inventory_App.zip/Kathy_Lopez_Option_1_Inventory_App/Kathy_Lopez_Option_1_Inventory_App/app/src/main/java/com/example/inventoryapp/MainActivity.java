
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Connect interface components.
        EditText username =
                findViewById(R.id.editTextUsername);

        EditText password =
                findViewById(R.id.editTextPassword);

        Button loginButton =
                findViewById(R.id.buttonLogin);

        Button createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        // Authenticate an existing user.
        loginButton.setOnClickListener(v -> {

            String enteredUsername =
                    username.getText().toString().trim();

            String enteredPassword =
                    password.getText().toString();

            // Validate required fields.
            if (enteredUsername.isEmpty()) {
                username.setError("Username is required");
                username.requestFocus();
                return;
            }

            if (enteredPassword.isEmpty()) {
                password.setError("Password is required");
                password.requestFocus();
                return;
            }

            // Verify credentials using SQLite.
            boolean isValidUser =
                    databaseHelper.validateUser(
                            enteredUsername,
                            enteredPassword
                    );

            if (isValidUser) {

                Toast.makeText(
                        MainActivity.this,
                        "Login successful",
                        Toast.LENGTH_SHORT
                ).show();

                // Navigate to the inventory screen.
                Intent intent = new Intent(
                        MainActivity.this,
                        InventoryActivity.class
                );

                startActivity(intent);
                finish();

            } else {

                password.setError(
                        "Invalid username or password"
                );

                password.requestFocus();
            }
        });

        // Register a new user account.
        createAccountButton.setOnClickListener(v -> {

            String newUsername =
                    username.getText().toString().trim();

            String newPassword =
                    password.getText().toString();

            // Validate username.
            if (newUsername.isEmpty()) {
                username.setError("Username is required");
                username.requestFocus();
                return;
            }

            // Validate password.
            if (newPassword.isEmpty()) {
                password.setError("Password is required");
                password.requestFocus();
                return;
            }

            if (newPassword.length() < 8) {
                password.setError(
                        "Password must contain at least 8 characters"
                );
                password.requestFocus();
                return;
            }

            // Store the new account in SQLite.
            boolean accountCreated =
                    databaseHelper.createUser(
                            newUsername,
                            newPassword
                    );

            if (accountCreated) {

                Toast.makeText(
                        MainActivity.this,
                        "Account created successfully. Please log in.",
                        Toast.LENGTH_LONG
                ).show();

                // Clear the password after registration.
                password.setText("");

            } else {

                username.setError(
                        "Unable to create account. " +
                                "Username may already exist."
                );

                username.requestFocus();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
