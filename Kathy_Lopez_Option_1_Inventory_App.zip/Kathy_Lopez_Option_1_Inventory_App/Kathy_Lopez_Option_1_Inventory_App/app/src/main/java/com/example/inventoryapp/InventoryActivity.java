
package com.example.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private LinearLayout inventoryContainer;

    private final int purple = Color.rgb(103, 80, 164);
    private final int darkText = Color.rgb(45, 40, 55);
    private final int lightPurple = Color.rgb(245, 241, 252);

    private int dp(int value) {
        return (int) (value *
                getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        inventoryContainer =
                findViewById(R.id.inventoryContainer);

        Button addItemButton =
                findViewById(R.id.buttonAddItem);

        addItemButton.setText("Add Item");

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this,
                    AddItemActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayItems();
    }

    private TextView createCell(
            String value, float weight, boolean bold) {

        TextView cell = new TextView(this);

        cell.setText(value);
        cell.setTextSize(14);
        cell.setTextColor(darkText);
        cell.setGravity(Gravity.CENTER_VERTICAL);

        cell.setPadding(
                dp(8), dp(12), dp(4), dp(12)
        );

        if (bold) {
            cell.setTypeface(null, Typeface.BOLD);
        }

        cell.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        weight
                )
        );

        return cell;
    }

    private Button createActionButton(
            String text, int color) {

        Button button = new Button(this);

        button.setText(text);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);

        button.setBackgroundTintList(
                ColorStateList.valueOf(color)
        );

        button.setMinHeight(dp(48));
        button.setMinimumHeight(dp(48));

        return button;
    }

    // Display inventory records stored in SQLite.
    @SuppressLint("SetTextI18n")
    private void displayItems() {

        inventoryContainer.removeAllViews();

        Button smsButton = createActionButton(
                "SMS Notifications", purple
        );

        smsButton.setTextSize(15);
        smsButton.setBackgroundTintList(null);
        smsButton.setBackground(background(purple, 24));

        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    this,
                    SmsNotificationActivity.class
            );
            startActivity(intent);
        });

        inventoryContainer.addView(smsButton);

        TextView title = new TextView(this);
        title.setText("Inventory Records");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(darkText);

        title.setPadding(
                dp(4), dp(20), dp(4), dp(6)
        );

        inventoryContainer.addView(title);

        TextView description = new TextView(this);

        description.setText(
                "View and manage your inventory items."
        );

        description.setTextSize(14);
        description.setTextColor(Color.DKGRAY);

        description.setPadding(
                dp(4), 0, dp(4), dp(16)
        );

        inventoryContainer.addView(description);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);

        header.setBackground(
                background(Color.rgb(224, 216, 241), 8)
        );

        header.addView(createCell("Item", 2, true));
        header.addView(createCell("Qty", 1, true));
        header.addView(createCell("Status", 2, true));

        inventoryContainer.addView(header);

        try (Cursor cursor = databaseHelper.getAllItems()) {

            if (cursor.getCount() == 0) {

                TextView empty = new TextView(this);

                empty.setText(
                        "No inventory items yet.\n" +
                                "Tap Add Item to get started."
                );

                empty.setTextSize(16);
                empty.setTextColor(darkText);
                empty.setGravity(Gravity.CENTER);

                empty.setPadding(
                        dp(12), dp(32), dp(12), dp(32)
                );

                inventoryContainer.addView(empty);
                return;
            }

            int idIndex =
                    cursor.getColumnIndexOrThrow("id");

            int nameIndex =
                    cursor.getColumnIndexOrThrow("name");

            int quantityIndex =
                    cursor.getColumnIndexOrThrow("quantity");

            while (cursor.moveToNext()) {

                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);

                String status = quantity == 0
                        ? "Out of Stock"
                        : "In Stock";

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);

                card.setBackground(
                        background(lightPurple, 10)
                );

                card.setPadding(
                        dp(6), dp(6), dp(6), dp(10)
                );

                LinearLayout.LayoutParams cardParams =
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );

                cardParams.setMargins(
                        0, dp(8), 0, dp(8)
                );

                card.setLayoutParams(cardParams);

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);

                TextView nameCell =
                        createCell(name, 2, true);

                TextView quantityCell =
                        createCell(
                                String.valueOf(quantity),
                                1,
                                false
                        );

                TextView statusCell =
                        createCell(status, 2, true);

                if (quantity == 0) {
                    statusCell.setTextColor(
                            Color.rgb(170, 40, 50)
                    );
                } else {
                    statusCell.setTextColor(
                            Color.rgb(35, 115, 65)
                    );
                }

                row.addView(nameCell);
                row.addView(quantityCell);
                row.addView(statusCell);

                card.addView(row);

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                actions.setGravity(Gravity.START);

                Button editButton =
                        createActionButton("Edit", purple);

                Button deleteButton =
                        createActionButton(
                                "Delete",
                                Color.rgb(155, 65, 80)
                        );

                LinearLayout.LayoutParams editParams =
                        new LinearLayout.LayoutParams(
                                dp(110), dp(48)
                        );

                editParams.setMargins(
                        dp(4), 0, dp(8), 0
                );

                LinearLayout.LayoutParams deleteParams =
                        new LinearLayout.LayoutParams(
                                dp(110), dp(48)
                        );

                editButton.setLayoutParams(editParams);
                deleteButton.setLayoutParams(deleteParams);

                editButton.setContentDescription(
                        "Edit " + name
                );

                deleteButton.setContentDescription(
                        "Delete " + name
                );

                actions.addView(editButton);
                actions.addView(deleteButton);

                card.addView(actions);
                inventoryContainer.addView(card);

                editButton.setOnClickListener(v ->
                        showEditDialog(id, name, quantity)
                );

                deleteButton.setOnClickListener(v ->
                        showDeleteDialog(id, name)
                );
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Unable to load inventory records",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Edit an inventory item and detect a new out-of-stock event.
    private void showEditDialog(
            int id, String name, int quantity) {

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        layout.setPadding(
                dp(24), dp(8), dp(24), dp(8)
        );

        EditText nameInput = new EditText(this);
        nameInput.setHint("Item Name");
        nameInput.setText(name);
        nameInput.setSingleLine(true);

        nameInput.setInputType(
                InputType.TYPE_CLASS_TEXT
        );

        EditText quantityInput = new EditText(this);
        quantityInput.setHint("Quantity");

        quantityInput.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );

        quantityInput.setText(
                String.valueOf(quantity)
        );

        layout.addView(nameInput);
        layout.addView(quantityInput);

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("Edit Inventory Item")
                        .setView(layout)
                        .setPositiveButton("Save", null)
                        .setNegativeButton("Cancel", null)
                        .create();

        dialog.setOnShowListener(ignored -> {

            Button saveButton =
                    dialog.getButton(
                            AlertDialog.BUTTON_POSITIVE
                    );

            saveButton.setOnClickListener(v -> {

                String newName =
                        nameInput.getText()
                                .toString().trim();

                String quantityText =
                        quantityInput.getText()
                                .toString().trim();

                if (newName.isEmpty()) {

                    nameInput.setError(
                            "Item name is required"
                    );

                    nameInput.requestFocus();
                    return;
                }

                if (quantityText.isEmpty()) {

                    quantityInput.setError(
                            "Quantity is required"
                    );

                    quantityInput.requestFocus();
                    return;
                }

                int newQuantity;

                try {
                    newQuantity =
                            Integer.parseInt(quantityText);

                } catch (NumberFormatException e) {

                    quantityInput.setError(
                            "Enter a valid whole number"
                    );

                    quantityInput.requestFocus();
                    return;
                }

                if (newQuantity < 0) {

                    quantityInput.setError(
                            "Quantity cannot be negative"
                    );

                    quantityInput.requestFocus();
                    return;
                }

                boolean updated =
                        databaseHelper.updateItem(
                                id, newName, newQuantity
                        );

                if (updated) {

                    Toast.makeText(
                            this,
                            "Item updated successfully",
                            Toast.LENGTH_SHORT
                    ).show();

                    dialog.dismiss();
                    displayItems();

                    // Alert only when stock changes from
                    // a positive quantity to zero.
                    if (quantity > 0 &&
                            databaseHelper.isItemOutOfStock(id)) {

                        showOutOfStockAlert(newName);
                    }

                } else {

                    Toast.makeText(
                            this,
                            "Unable to update item",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        });

        dialog.show();
    }

    // Send an SMS only after an item transitions from positive stock to zero.
    // A failed or unavailable SMS never blocks inventory updates.
    private void showOutOfStockAlert(String itemName) {
        boolean permissionGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;

        SharedPreferences settings = getSharedPreferences(
                "sms_settings", MODE_PRIVATE
        );
        String destination = settings.getString("phone_number", "").trim();

        if (!permissionGranted) {
            showAlert(itemName + " is out of stock. SMS permission is " +
                    "not granted. Inventory management still works.");
            return;
        }

        if (!destination.matches("\\+?[0-9]{3,15}")) {
            showAlert(itemName + " is out of stock. Configure an SMS " +
                    "destination in SMS Notifications to receive alerts.");
            return;
        }

        String smsText = "Inventory alert: " + itemName + " is out of stock.";
        String action = getPackageName() + ".SMS_SENT_" + System.nanoTime();
        BroadcastReceiver sentReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                try {
                    if (getResultCode() == RESULT_OK) {
                        Toast.makeText(context,
                                "SMS sent by Android. Check the receiving emulator.",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(context,
                                "SMS could not be sent. Inventory was saved.",
                                Toast.LENGTH_LONG).show();
                    }
                } finally {
                    unregisterReceiver(this);
                }
            }
        };

        try {
            IntentFilter filter = new IntentFilter(action);
            registerReceiver(sentReceiver, filter, Context.RECEIVER_EXPORTED);

            Intent sentIntent = new Intent(action).setPackage(getPackageName());
            PendingIntent sentPendingIntent = PendingIntent.getBroadcast(
                    this, 0, sentIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            SmsManager manager;
            manager = getSystemService(SmsManager.class);
            if (manager == null) {
                unregisterReceiver(sentReceiver);
                showAlert("SMS service is unavailable. Inventory was saved.");
                return;
            }

            manager.sendTextMessage(destination, null, smsText,
                    sentPendingIntent, null);
            showAlert(itemName + " is out of stock. SMS send requested " +
                    "for your configured destination. Check the second emulator " +
                    "for delivery.");
        } catch (Exception e) {
            try {
                unregisterReceiver(sentReceiver);
            } catch (IllegalArgumentException ignored) {
                // Receiver may not have been registered.
            }
            showAlert("Out-of-stock item saved, but SMS sending failed.");
        }
    }

    private void showAlert(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Out-of-Stock Alert")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    // Confirm deletion before removing a record.
    private void showDeleteDialog(int id, String name) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Inventory Item")
                .setMessage(
                        "Are you sure you want to delete " +
                                name + "?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {

                            boolean deleted =
                                    databaseHelper.deleteItem(id);

                            if (deleted) {

                                Toast.makeText(
                                        this,
                                        "Item deleted successfully",
                                        Toast.LENGTH_SHORT
                                ).show();

                                displayItems();

                            } else {

                                Toast.makeText(
                                        this,
                                        "Unable to delete item",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onDestroy() {

        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
