
package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private EditText itemNameInput;
    private EditText quantityInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        // Adjust the layout for system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (view, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // Initialize the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Connect the interface components.
        itemNameInput =
                findViewById(R.id.editTextItemName);

        quantityInput =
                findViewById(R.id.editTextQuantity);

        Button saveButton =
                findViewById(R.id.buttonSave);

        // Save the inventory item when clicked.
        saveButton.setOnClickListener(v -> saveInventoryItem());
    }

    // Validate user input and save a new inventory record.
    private void saveInventoryItem() {

        String name = itemNameInput.getText()
                .toString().trim();

        String quantityText = quantityInput.getText()
                .toString().trim();

        // Validate the item name.
        if (name.isEmpty()) {

            itemNameInput.setError(
                    "Item name is required"
            );

            itemNameInput.requestFocus();
            return;
        }

        // Validate the quantity field.
        if (quantityText.isEmpty()) {

            quantityInput.setError(
                    "Quantity is required"
            );

            quantityInput.requestFocus();
            return;
        }

        int itemQuantity;

        // Ensure the quantity is a valid whole number.
        try {
            itemQuantity = Integer.parseInt(quantityText);

        } catch (NumberFormatException e) {

            quantityInput.setError(
                    "Enter a valid whole number"
            );

            quantityInput.requestFocus();
            return;
        }

        // Prevent negative inventory quantities.
        if (itemQuantity < 0) {

            quantityInput.setError(
                    "Quantity cannot be negative"
            );

            quantityInput.requestFocus();
            return;
        }

        // Save the validated item to SQLite.
        boolean saved = databaseHelper.addItem(
                name,
                itemQuantity
        );

        if (saved) {

            Toast.makeText(
                    this,
                    "Item saved successfully",
                    Toast.LENGTH_SHORT
            ).show();

            // Return to the inventory screen.
            finish();

        } else {

            Toast.makeText(
                    this,
                    "Unable to save item. Please try again.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    @Override
    protected void onDestroy() {

        // Close the database helper when finished.
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
