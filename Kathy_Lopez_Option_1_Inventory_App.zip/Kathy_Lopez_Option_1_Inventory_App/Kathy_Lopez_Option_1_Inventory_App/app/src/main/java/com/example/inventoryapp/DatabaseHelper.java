package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME =
            "InventoryDatabase.db";

    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_INVENTORY = "inventory";
    private static final String TABLE_USERS = "users";

    private static final int HASH_ITERATIONS = 120000;
    private static final int HASH_LENGTH = 256;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createInventoryTable(db);
        createUsersTable(db);
    }

    // Create the inventory table.
    private void createInventoryTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL CHECK(quantity >= 0))"
        );
    }

    // Create the user accounts table.
    private void createUsersTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash BLOB NOT NULL, " +
                        "password_salt BLOB NOT NULL)"
        );
    }

    // Preserve inventory records during database upgrades.
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        if (oldVersion < 2) {
            createUsersTable(db);
        }
    }

    // Add a new inventory item.
    public boolean addItem(String name, int quantity) {

        if (name == null ||
                name.trim().isEmpty() ||
                quantity < 0) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("quantity", quantity);

        return db.insert(
                TABLE_INVENTORY,
                null,
                values
        ) != -1;
    }

    // Retrieve all inventory items.
    // The caller must close the returned Cursor.
    public Cursor getAllItems() {

        return getReadableDatabase().rawQuery(
                "SELECT * FROM inventory ORDER BY id DESC",
                null
        );
    }

    // Update an existing inventory item.
    public boolean updateItem(
            int id,
            String name,
            int quantity) {

        if (id <= 0 ||
                name == null ||
                name.trim().isEmpty() ||
                quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("quantity", quantity);

        int result = getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Delete an inventory item using its unique ID.
    public boolean deleteItem(int id) {

        if (id <= 0) {
            return false;
        }

        int result = getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Create a user account with a salted password hash.
    public boolean createUser(
            String username,
            String password) {

        if (username == null ||
                username.trim().isEmpty() ||
                password == null ||
                password.length() < 8) {
            return false;
        }

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        char[] passwordChars = password.toCharArray();

        try {

            byte[] hash =
                    hashPassword(passwordChars, salt);

            ContentValues values = new ContentValues();

            values.put(
                    "username",
                    username.trim()
            );

            values.put(
                    "password_hash",
                    hash
            );

            values.put(
                    "password_salt",
                    salt
            );

            long result = getWritableDatabase().insert(
                    TABLE_USERS,
                    null,
                    values
            );

            return result != -1;

        } catch (Exception e) {

            return false;

        } finally {

            Arrays.fill(passwordChars, '\0');
        }
    }

    // Verify login credentials against the users table.
    public boolean validateUser(
            String username,
            String password) {

        if (username == null || password == null) {
            return false;
        }

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{
                        "password_hash",
                        "password_salt"
                },
                "username=?",
                new String[]{username.trim()},
                null,
                null,
                null
        )) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] savedHash = cursor.getBlob(0);
            byte[] salt = cursor.getBlob(1);

            char[] passwordChars =
                    password.toCharArray();

            try {

                byte[] enteredHash =
                        hashPassword(passwordChars, salt);

                return MessageDigest.isEqual(
                        savedHash,
                        enteredHash
                );

            } finally {

                Arrays.fill(passwordChars, '\0');
            }

        } catch (Exception e) {

            return false;
        }
    }

    // Derive a password hash using PBKDF2.
    private byte[] hashPassword(
            char[] password,
            byte[] salt) throws Exception {

        PBEKeySpec spec = new PBEKeySpec(
                password,
                salt,
                HASH_ITERATIONS,
                HASH_LENGTH
        );

        try {

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            return factory.generateSecret(spec)
                    .getEncoded();

        } finally {

            spec.clearPassword();
        }
    }

    // Check whether an inventory item is out of stock.
    public boolean isItemOutOfStock(int itemId) {

        if (itemId <= 0) {
            return false;
        }

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{"quantity"},
                "id=?",
                new String[]{String.valueOf(itemId)},
                null,
                null,
                null
        )) {

            if (cursor.moveToFirst()) {
                return cursor.getInt(0) == 0;
            }

            return false;
        }
    }
}
