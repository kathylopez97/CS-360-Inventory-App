
package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {

    private TextView smsStatus;

    // Handle the result of the SMS permission request.
    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {

                        if (granted) {

                            smsStatus.setText(
                                    "SMS Permission: Granted"
                            );

                            Toast.makeText(
                                    this,
                                    "SMS permission granted",
                                    Toast.LENGTH_SHORT
                            ).show();

                        } else {

                            smsStatus.setText(
                                    "SMS Permission: Denied. " +
                                            "Inventory management remains available."
                            );

                            Toast.makeText(
                                    this,
                                    "SMS permission denied. " +
                                            "You can still use the app.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sms_notification);

        smsStatus = findViewById(R.id.textViewSmsStatus);

        Button allowButton =
                findViewById(R.id.buttonAllowSms);

        Button skipButton =
                findViewById(R.id.buttonSkipSms);

        updatePermissionStatus();

        // Ask for SMS permission only when the user chooses.
        allowButton.setOnClickListener(v -> {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED) {

                updatePermissionStatus();

            } else {

                permissionLauncher.launch(
                        Manifest.permission.SEND_SMS
                );
            }
        });

        // Continue using the app without SMS permission.
        skipButton.setOnClickListener(v -> finish());

        // Add a button for configuring the SMS destination.
        Button configureButton = new Button(this);

        configureButton.setText(
                "Configure SMS Destination"
        );

        configureButton.setAllCaps(false);

        configureButton.setOnClickListener(
                v -> showPhoneNumberDialog()
        );

        // Add the button to the existing screen.
        android.view.ViewGroup parent =
                (android.view.ViewGroup) smsStatus.getParent();

        if (parent instanceof LinearLayout) {

            ((LinearLayout) parent).addView(
                    configureButton
            );

        } else {

            Toast.makeText(
                    this,
                    "SMS destination button requires " +
                            "a LinearLayout container.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Display the current SMS permission status.
    private void updatePermissionStatus() {

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted) {

            smsStatus.setText(
                    "SMS Permission: Granted"
            );

        } else {

            smsStatus.setText(
                    "SMS Permission: Not Granted. " +
                            "SMS alerts are optional."
            );
        }
    }

    // Allow the user to save a destination for SMS alerts.
    private void showPhoneNumberDialog() {

        SharedPreferences preferences =
                getSharedPreferences(
                        "sms_settings",
                        MODE_PRIVATE
                );

        EditText phoneInput = new EditText(this);

        phoneInput.setHint(
                "Notification phone number"
        );

        phoneInput.setInputType(
                InputType.TYPE_CLASS_PHONE
        );

        phoneInput.setText(
                preferences.getString(
                        "phone_number",
                        ""
                )
        );

        LinearLayout layout = new LinearLayout(this);

        layout.setOrientation(
                LinearLayout.VERTICAL
        );

        int padding = (int) (
                24 * getResources()
                        .getDisplayMetrics().density
        );

        layout.setPadding(
                padding,
                padding / 2,
                padding,
                padding / 2
        );

        layout.addView(phoneInput);

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("SMS Alert Destination")
                        .setMessage(
                                "Enter a phone number that you own " +
                                        "or have permission to notify."
                        )
                        .setView(layout)
                        .setPositiveButton("Save", null)
                        .setNegativeButton("Cancel", null)
                        .create();

        dialog.setOnShowListener(ignored -> {

            Button saveButton =
                    dialog.getButton(
                            AlertDialog.BUTTON_POSITIVE
                    );

            saveButton.setOnClickListener(v -> {

                String number =
                        phoneInput.getText()
                                .toString().trim();

                // Basic number validation.
                if (!number.matches("\\+?[0-9]{3,15}")) {

                    phoneInput.setError(
                            "Enter a valid phone number"
                    );

                    phoneInput.requestFocus();
                    return;
                }

                preferences.edit()
                        .putString(
                                "phone_number",
                                number
                        )
                        .apply();

                Toast.makeText(
                        this,
                        "SMS destination saved",
                        Toast.LENGTH_SHORT
                ).show();

                dialog.dismiss();
            });
        });

        dialog.show();
    }
}
